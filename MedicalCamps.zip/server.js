const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const db = new sqlite3.Database('./medical.db', (err) => {
    if (err) console.error('❌ خطأ:', err.message);
    else console.log('✅ متصل بقاعدة medical.db');
});

// ========== إنشاء الجداول ==========
db.serialize(() => {
    // جدول الأصناف
    db.run(`
        CREATE TABLE IF NOT EXISTS Items (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            Unit TEXT NOT NULL,
            Price REAL DEFAULT 0,
            RequiredQty REAL DEFAULT 0,
            AvailableQty REAL DEFAULT 0
        )
    `);

    // جدول المخيمات
    db.run(`
        CREATE TABLE IF NOT EXISTS Camps (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            StartDate TEXT,
            EndDate TEXT,
            CasesCount INTEGER DEFAULT 0
        )
    `);

    // جدول الجرد
    db.run(`
        CREATE TABLE IF NOT EXISTS Inventory (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ItemId INTEGER NOT NULL,
            CampId INTEGER NOT NULL,
            BeforeQty REAL DEFAULT 0,
            AfterQty REAL DEFAULT 0,
            UNIQUE(ItemId, CampId),
            FOREIGN KEY (ItemId) REFERENCES Items(Id) ON DELETE CASCADE,
            FOREIGN KEY (CampId) REFERENCES Camps(Id) ON DELETE CASCADE
        )
    `);

    // جدول المشتريات
    db.run(`
        CREATE TABLE IF NOT EXISTS Purchases (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ItemId INTEGER NOT NULL,
            Qty REAL NOT NULL,
            Price REAL NOT NULL,
            CampId INTEGER NOT NULL,
            Date TEXT,
            FOREIGN KEY (ItemId) REFERENCES Items(Id) ON DELETE CASCADE,
            FOREIGN KEY (CampId) REFERENCES Camps(Id) ON DELETE CASCADE
        )
    `);

    // جدول المستحقات
  db.run(`
    CREATE TABLE IF NOT EXISTS Payments (
        Id INTEGER PRIMARY KEY AUTOINCREMENT,
        TransNo TEXT UNIQUE DEFAULT '',
        Name TEXT NOT NULL,
        Specialization TEXT DEFAULT '',
        NumberOfDays INTEGER DEFAULT 0,
        DailyAmount REAL DEFAULT 0,
        Total REAL DEFAULT 0,
        Paid REAL DEFAULT 0,
        Remaining REAL DEFAULT 0,
        ClosedBalance INTEGER DEFAULT 0,
        CampId INTEGER NOT NULL,
        FOREIGN KEY (CampId) REFERENCES Camps(Id) ON DELETE CASCADE
    )
`);
    console.log('✅ تم إنشاء جميع الجداول');
});

// ========== دالة تحديث الكمية المتوفرة ==========
function updateAvailableQty(itemId, callback) {
    db.run(`
        UPDATE Items 
        SET AvailableQty = (
            SELECT COALESCE(SUM(AfterQty), 0)
            FROM Inventory
            WHERE ItemId = Items.Id
        )
        WHERE Id = ?
    `, [itemId], (err) => {
        if (err) console.error('❌ خطأ في تحديث الكمية:', err.message);
        if (callback) callback(err);
    });
}

// ========== دالة تحديث جميع الكميات المتوفرة ==========
function updateAllAvailableQtys() {
    db.run(`
        UPDATE Items 
        SET AvailableQty = (
            SELECT COALESCE(SUM(AfterQty), 0)
            FROM Inventory
            WHERE ItemId = Items.Id
        )
    `, (err) => {
        if (err) console.error('❌ خطأ:', err.message);
        else console.log('✅ تم تحديث جميع الكميات المتوفرة');
    });
}

// ========== مزامنة الرصيد السابق للمخيم الجديد ==========
app.post('/api/sync-to-new-camp', (req, res) => {
    const { fromCampId, toCampId } = req.body;
    
    if (!fromCampId || !toCampId) {
        return res.status(400).json({ error: 'يجب تحديد المخيم المصدر والمخيم الهدف' });
    }
    
    // جلب الرصيد النهائي من المخيم المصدر وتحديث الرصيد السابق للمخيم الهدف
    db.run(`
        INSERT INTO Inventory (ItemId, CampId, BeforeQty, AfterQty)
        SELECT 
            i.ItemId,
            ? as CampId,
            i.AfterQty as BeforeQty,
            0 as AfterQty
        FROM Inventory i
        WHERE i.CampId = ?
        ON CONFLICT(ItemId, CampId) DO UPDATE SET
            BeforeQty = excluded.BeforeQty,
            AfterQty = excluded.AfterQty
    `, [toCampId, fromCampId], (err) => {
        if (err) {
            console.error('❌ خطأ في المزامنة:', err.message);
            return res.status(500).json({ error: err.message });
        }
        
        // تحديث الكمية المتوفرة
        updateAllAvailableQtys();
        
        res.json({ 
            success: true, 
            message: `تم مزامنة الرصيد من المخيم ${fromCampId} إلى المخيم ${toCampId}` 
        });
    });
});

// ========== API Routes للأصناف ==========
app.get('/api/items', (req, res) => {
    db.all("SELECT * FROM Items ORDER BY Id", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.get('/api/items/:id', (req, res) => {
    db.get("SELECT * FROM Items WHERE Id = ?", [req.params.id], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(row);
    });
});

app.post('/api/items', (req, res) => {
    const { Name, Unit, Price, RequiredQty = 0 } = req.body;
    db.run(
        "INSERT INTO Items (Name, Unit, Price, RequiredQty, AvailableQty) VALUES (?, ?, ?, ?, 0)",
        [Name, Unit, Price || 0, RequiredQty],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            
            // تهيئة الجرد للمخيمات الموجودة
            db.all("SELECT Id FROM Camps", [], (err, camps) => {
                if (!err && camps) {
                    camps.forEach(camp => {
                        db.run(`
                            INSERT INTO Inventory (ItemId, CampId, BeforeQty, AfterQty)
                            VALUES (?, ?, 0, 0)
                            ON CONFLICT(ItemId, CampId) DO NOTHING
                        `, [this.lastID, camp.Id]);
                    });
                }
            });
            
            res.json({ Id: this.lastID });
        }
    );
});

app.put('/api/items/:id', (req, res) => {
    const { Name, Unit, Price, RequiredQty } = req.body;
    db.run(
        "UPDATE Items SET Name = ?, Unit = ?, Price = ?, RequiredQty = ? WHERE Id = ?",
        [Name, Unit, Price, RequiredQty, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
});

app.delete('/api/items/:id', (req, res) => {
    db.run("DELETE FROM Items WHERE Id = ?", [req.params.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: this.changes });
    });
});

// ========== API Routes للمخيمات ==========
app.get('/api/camps', (req, res) => {
    db.all("SELECT * FROM Camps ORDER BY Id DESC", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.post('/api/camps', (req, res) => {
    const { Name, StartDate, EndDate, CasesCount = 0 } = req.body;
    db.run(
        "INSERT INTO Camps (Name, StartDate, EndDate, CasesCount) VALUES (?, ?, ?, ?)",
        [Name, StartDate, EndDate, CasesCount],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            const newCampId = this.lastID;
            
            // تهيئة الجرد للمخيم الجديد (BeforeQty = 0 مؤقتاً)
            db.all("SELECT Id FROM Items", [], (err, items) => {
                if (!err && items) {
                    items.forEach(item => {
                        db.run(`
                            INSERT INTO Inventory (ItemId, CampId, BeforeQty, AfterQty)
                            VALUES (?, ?, 0, 0)
                            ON CONFLICT(ItemId, CampId) DO NOTHING
                        `, [item.Id, newCampId]);
                    });
                }
            });
            
            res.json({ Id: newCampId });
        }
    );
});

app.put('/api/camps/:id', (req, res) => {
    const { Name, StartDate, EndDate, CasesCount } = req.body;
    db.run(
        "UPDATE Camps SET Name = ?, StartDate = ?, EndDate = ?, CasesCount = ? WHERE Id = ?",
        [Name, StartDate, EndDate, CasesCount, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
});

// ========== API Routes للجرد ==========
app.get('/api/inventory/:campId', (req, res) => {
    const campId = req.params.campId;
    
    db.all(`
        SELECT i.Id, i.Name, i.Unit, i.Price, i.AvailableQty, i.RequiredQty,
               COALESCE(inv.BeforeQty, 0) as BeforeQty,
               COALESCE(inv.AfterQty, 0) as AfterQty
        FROM Items i
        LEFT JOIN Inventory inv ON inv.ItemId = i.Id AND inv.CampId = ?
        ORDER BY i.Id
    `, [campId], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        
        const result = rows.map(row => ({
            ...row,
            RequiredForWork: row.RequiredQty || 0
        }));
        
        res.json(result);
    });
});

app.put('/api/inventory', (req, res) => {
    const { ItemId, CampId, BeforeQty, AfterQty } = req.body;
    db.run(
        `INSERT INTO Inventory (ItemId, CampId, BeforeQty, AfterQty)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(ItemId, CampId) DO UPDATE SET
         BeforeQty = excluded.BeforeQty,
         AfterQty = excluded.AfterQty`,
        [ItemId, CampId, BeforeQty, AfterQty],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            updateAvailableQty(ItemId, () => {
                res.json({ success: true });
            });
        }
    );
});

// ========== API Routes للمشتريات (معدلة) ==========
app.get('/api/purchases/:campId', (req, res) => {
    const campId = req.params.campId;
    db.all(`
        SELECT p.*, i.Name as ItemName, i.Unit, i.Price as ItemPrice
        FROM Purchases p
        JOIN Items i ON p.ItemId = i.Id
        WHERE p.CampId = ?
        ORDER BY p.Date DESC
    `, [campId], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.post('/api/purchases', (req, res) => {
    const { ItemId, Qty, Price, CampId, Date } = req.body;
    
    // أولاً: جلب الرصيد الحالي للمخيم
    db.get(`
        SELECT BeforeQty, AfterQty FROM Inventory 
        WHERE ItemId = ? AND CampId = ?
    `, [ItemId, CampId], (err, inventory) => {
        if (err) return res.status(500).json({ error: err.message });
        
        const currentAfterQty = inventory ? inventory.AfterQty : 0;
        const newAfterQty = currentAfterQty + Qty;
        
        // إضافة سجل الشراء
        db.run(
            "INSERT INTO Purchases (ItemId, Qty, Price, CampId, Date) VALUES (?, ?, ?, ?, ?)",
            [ItemId, Qty, Price, CampId, Date || new Date().toISOString()],
            function(err) {
                if (err) return res.status(500).json({ error: err.message });
                
                // تحديث AfterQty في الجرد (إضافة المشتريات إلى الرصيد النهائي)
                db.run(
                    `INSERT INTO Inventory (ItemId, CampId, BeforeQty, AfterQty)
                     VALUES (?, ?, ?, ?)
                     ON CONFLICT(ItemId, CampId) DO UPDATE SET
                     AfterQty = COALESCE(AfterQty, 0) + ?`,
                    [ItemId, CampId, inventory ? inventory.BeforeQty : 0, newAfterQty, Qty],
                    (updateErr) => {
                        if (updateErr) console.error('⚠️ خطأ:', updateErr.message);
                        updateAvailableQty(ItemId, () => {
                            res.json({ Id: this.lastID, newAfterQty });
                        });
                    }
                );
            }
        );
    });
});
// ========== إنشاء جدول Payments بالأعمدة الجديدة ==========


// إضافة الأعمدة الجديدة إذا لم تكن موجودة
db.run(`ALTER TABLE Payments ADD COLUMN TransNo TEXT DEFAULT ''`, (err) => {
    if (err && !err.message.includes('duplicate column name')) {
        console.log('⚠️ عمود TransNo موجود مسبقاً');
    }
});

db.run(`ALTER TABLE Payments ADD COLUMN ClosedBalance INTEGER DEFAULT 0`, (err) => {
    if (err && !err.message.includes('duplicate column name')) {
        console.log('⚠️ عمود ClosedBalance موجود مسبقاً');
    }
});

// ========== دوال مساعدة ==========
function generateTransNo() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `TRX-${year}${month}${day}-${random}`;
}

// ========== API Routes لـ Payments ==========

// جلب جميع المستحقات لمخيم معين (فقط غير المغلقة أو الكل حسب الطلب)
app.get('/api/payments/:campId', (req, res) => {
    const campId = req.params.campId;
    const showClosed = req.query.showClosed === 'true';
    
    let query = `
        SELECT Id, TransNo, Name, Specialization, NumberOfDays, DailyAmount, 
               Total, Paid, (Total - Paid) as Remaining, ClosedBalance, CampId
        FROM Payments 
        WHERE CampId = ?
    `;
    
    if (!showClosed) {
        query += " AND ClosedBalance = 0";
    }
    
    query += " ORDER BY Id DESC";
    
    db.all(query, [campId], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// إضافة مستحق جديد
app.post('/api/payments', (req, res) => {
    const { 
        Name, 
        Specialization, 
        NumberOfDays, 
        DailyAmount, 
        Total, 
        Paid, 
        CampId 
    } = req.body;
    
    const calculatedTotal = Total || (NumberOfDays * DailyAmount);
    const remaining = calculatedTotal - (Paid || 0);
    const transNo = generateTransNo();
    
    db.run(
        `INSERT INTO Payments (TransNo, Name, Specialization, NumberOfDays, DailyAmount, Total, Paid, Remaining, ClosedBalance, CampId) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`,
        [transNo, Name, Specialization || '', NumberOfDays || 0, DailyAmount || 0, 
         calculatedTotal, Paid || 0, remaining, CampId],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ 
                Id: this.lastID,
                TransNo: transNo
            });
        }
    );
});
// ========== Dashboard API ==========
app.get('/api/dashboard/:campId', (req, res) => {
    const campId = req.params.campId;
    
    // 1. معلومات المخيم
    db.get("SELECT * FROM Camps WHERE Id = ?", [campId], (err, camp) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!camp) return res.status(404).json({ error: "المخيم غير موجود" });
        
        // 2. جرد الأصناف للمخيم
        db.all(`
            SELECT i.Id, i.Name, i.Unit, i.Price, i.RequiredQty,
                   COALESCE(inv.BeforeQty, 0) as BeforeQty,
                   COALESCE(inv.AfterQty, 0) as AfterQty,
                   (COALESCE(inv.BeforeQty, 0) - COALESCE(inv.AfterQty, 0)) as Consumption,
                   (i.RequiredQty - COALESCE(inv.AfterQty, 0)) as ToPurchase
            FROM Items i
            LEFT JOIN Inventory inv ON inv.ItemId = i.Id AND inv.CampId = ?
            ORDER BY i.Id
        `, [campId], (err, inventory) => {
            if (err) return res.status(500).json({ error: err.message });
            
            // 3. المشتريات
            db.all(`
                SELECT p.*, i.Name as ItemName, i.Unit
                FROM Purchases p
                JOIN Items i ON p.ItemId = i.Id
                WHERE p.CampId = ?
                ORDER BY p.Date DESC
            `, [campId], (err, purchases) => {
                if (err) return res.status(500).json({ error: err.message });
                
                // 4. المستحقات المالية
                db.all(`
                    SELECT Id, TransNo, Name, Specialization, NumberOfDays, DailyAmount,
                           Total, Paid, (Total - Paid) as Remaining, ClosedBalance
                    FROM Payments 
                    WHERE CampId = ?
                    ORDER BY ClosedBalance ASC, Id DESC
                `, [campId], (err, payments) => {
                    if (err) return res.status(500).json({ error: err.message });
                    
                    // حساب الإجماليات
                    const totals = {
                        totalBefore: inventory.reduce((sum, item) => sum + (item.BeforeQty || 0), 0),
                        totalAfter: inventory.reduce((sum, item) => sum + (item.AfterQty || 0), 0),
                        totalConsumption: inventory.reduce((sum, item) => sum + (item.Consumption || 0), 0),
                        totalToPurchase: inventory.reduce((sum, item) => sum + (Math.max(0, item.ToPurchase || 0)), 0),
                        totalPurchasesQty: purchases.reduce((sum, p) => sum + (p.Qty || 0), 0),
                        totalPurchasesValue: purchases.reduce((sum, p) => sum + ((p.Qty || 0) * (p.Price || 0)), 0),
                        totalPayments: payments.reduce((sum, p) => sum + (p.Total || 0), 0),
                        totalPaid: payments.reduce((sum, p) => sum + (p.Paid || 0), 0),
                        totalRemaining: payments.reduce((sum, p) => sum + ((p.Total - p.Paid) || 0), 0)
                    };
                    
                    res.json({
                        camp,
                        inventory,
                        purchases,
                        payments,
                        totals
                    });
                });
            });
        });
    });
});
// تحديث مستحق
app.put('/api/payments/:id', (req, res) => {
    const { Name, Specialization, NumberOfDays, DailyAmount, Total, Paid } = req.body;
    const calculatedTotal = Total || (NumberOfDays * DailyAmount);
    const remaining = calculatedTotal - (Paid || 0);
    
    db.run(
        `UPDATE Payments SET 
            Name = ?, 
            Specialization = ?, 
            NumberOfDays = ?, 
            DailyAmount = ?, 
            Total = ?, 
            Paid = ?, 
            Remaining = ?
         WHERE Id = ?`,
        [Name, Specialization || '', NumberOfDays || 0, DailyAmount || 0, 
         calculatedTotal, Paid || 0, remaining, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
});

// إغلاق مستحق (تصفية الحساب)
app.put('/api/payments/close/:id', (req, res) => {
    const { id } = req.params;
    
    db.run(
        `UPDATE Payments SET ClosedBalance = 1 WHERE Id = ?`,
        [id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ closed: this.changes });
        }
    );
});

// إعادة فتح مستحق
app.put('/api/payments/reopen/:id', (req, res) => {
    const { id } = req.params;
    
    db.run(
        `UPDATE Payments SET ClosedBalance = 0 WHERE Id = ?`,
        [id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ reopened: this.changes });
        }
    );
});

// حذف مستحق
app.delete('/api/payments/:id', (req, res) => {
    db.run("DELETE FROM Payments WHERE Id = ?", [req.params.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: this.changes });
    });
});

// استيراد المستحقات مع منع التكرار
app.post('/api/payments/import', (req, res) => {
    const { payments, campId } = req.body;
    
    if (!payments || !Array.isArray(payments)) {
        return res.status(400).json({ error: 'بيانات غير صالحة' });
    }
    
    let imported = 0;
    let updated = 0;
    let skipped = 0;
    
    const processPayment = (payment, callback) => {
        // البحث عن مستحق بنفس الاسم والتخصص والمخيم
        db.get(
            `SELECT Id, TransNo, Total, Paid, ClosedBalance FROM Payments 
             WHERE Name = ? AND Specialization = ? AND CampId = ?`,
            [payment.Name, payment.Specialization || '', campId],
            (err, existing) => {
                if (err) return callback(err);
                
                if (existing) {
                    // إذا كان موجوداً وغير مغلق، نقوم بتحديثه
                    if (existing.ClosedBalance === 0) {
                        const newTotal = payment.Total || existing.Total;
                        const newPaid = payment.Paid || existing.Paid;
                        const newRemaining = newTotal - newPaid;
                        
                        db.run(
                            `UPDATE Payments SET 
                                NumberOfDays = ?, 
                                DailyAmount = ?, 
                                Total = ?, 
                                Paid = ?, 
                                Remaining = ?
                             WHERE Id = ?`,
                            [payment.NumberOfDays || 0, payment.DailyAmount || 0,
                             newTotal, newPaid, newRemaining, existing.Id],
                            (err) => {
                                if (err) callback(err);
                                else {
                                    updated++;
                                    callback(null);
                                }
                            }
                        );
                    } else {
                        skipped++;
                        callback(null);
                    }
                } else {
                    // إضافة جديدة
                    const transNo = generateTransNo();
                    const calculatedTotal = payment.Total || (payment.NumberOfDays * payment.DailyAmount);
                    const remaining = calculatedTotal - (payment.Paid || 0);
                    
                    db.run(
                        `INSERT INTO Payments (TransNo, Name, Specialization, NumberOfDays, DailyAmount, Total, Paid, Remaining, ClosedBalance, CampId) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`,
                        [transNo, payment.Name, payment.Specialization || '', 
                         payment.NumberOfDays || 0, payment.DailyAmount || 0,
                         calculatedTotal, payment.Paid || 0, remaining, campId],
                        (err) => {
                            if (err) callback(err);
                            else {
                                imported++;
                                callback(null);
                            }
                        }
                    );
                }
            }
        );
    };
    
    let completed = 0;
    payments.forEach(payment => {
        processPayment(payment, (err) => {
            if (err) console.error('خطأ في الاستيراد:', err);
            completed++;
            if (completed === payments.length) {
                res.json({ 
                    success: true, 
                    imported, 
                    updated, 
                    skipped,
                    message: `تم الاستيراد: ${imported} جديد, ${updated} تحديث, ${skipped} مكرر`
                });
            }
        });
    });
});
// ========== API Routes للمستحقات ==========
app.get('/api/payments/:campId', (req, res) => {
    const campId = req.params.campId;
    db.all(`
        SELECT Id, Name, Specialization, NumberOfDays, DailyAmount, 
               Total, Paid, (Total - Paid) as Remaining, CampId
        FROM Payments 
        WHERE CampId = ?
        ORDER BY Id DESC
    `, [campId], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.post('/api/payments', (req, res) => {
    const { Name, Specialization, NumberOfDays, DailyAmount, Total, Paid, CampId } = req.body;
    const calculatedTotal = Total || (NumberOfDays * DailyAmount);
    const remaining = calculatedTotal - (Paid || 0);
    
    db.run(
        `INSERT INTO Payments (Name, Specialization, NumberOfDays, DailyAmount, Total, Paid, Remaining, CampId) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [Name, Specialization || '', NumberOfDays || 0, DailyAmount || 0, 
         calculatedTotal, Paid || 0, remaining, CampId],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ Id: this.lastID });
        }
    );
});

app.put('/api/payments/:id', (req, res) => {
    const { Name, Specialization, NumberOfDays, DailyAmount, Total, Paid } = req.body;
    const calculatedTotal = Total || (NumberOfDays * DailyAmount);
    const remaining = calculatedTotal - (Paid || 0);
    
    db.run(
        `UPDATE Payments SET 
            Name = ?, Specialization = ?, NumberOfDays = ?, DailyAmount = ?, 
            Total = ?, Paid = ?, Remaining = ?
         WHERE Id = ?`,
        [Name, Specialization || '', NumberOfDays || 0, DailyAmount || 0, 
         calculatedTotal, Paid || 0, remaining, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ updated: this.changes });
        }
    );
});

app.delete('/api/payments/:id', (req, res) => {
    db.run("DELETE FROM Payments WHERE Id = ?", [req.params.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: this.changes });
    });
});

// ========== التقارير ==========
app.get('/api/report/available', (req, res) => {
    db.all(`
        SELECT Id, Name, Unit, AvailableQty, Price, RequiredQty,
               (AvailableQty * Price) as TotalValue
        FROM Items 
        ORDER BY AvailableQty DESC
    `, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.get('/api/report/low-stock', (req, res) => {
    const threshold = req.query.threshold || 10;
    db.all(`
        SELECT Id, Name, Unit, AvailableQty, Price, RequiredQty
        FROM Items 
        WHERE AvailableQty <= ?
        ORDER BY AvailableQty ASC
    `, [threshold], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// تشغيل السيرفر
app.listen(port, () => {
    console.log(`\n🚀 السيرفر يعمل على: http://localhost:${port}`);
    console.log(`📁 مجلد الملفات الثابتة: public/\n`);
    setTimeout(() => updateAllAvailableQtys(), 1000);
});